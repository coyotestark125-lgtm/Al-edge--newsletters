import { eq, and } from "drizzle-orm";
import { getDb } from "./db";
import { 
  subscriptionTiers, 
  userSubscriptions, 
  premiumContent, 
  subscribers,
  InsertSubscriptionTier,
  InsertUserSubscription,
  InsertPremiumContent,
  InsertSubscriber
} from "../drizzle/schema";

// Subscription Tier Helpers
export async function getSubscriptionTiers() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(subscriptionTiers);
}

export async function getSubscriptionTierById(tierId: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(subscriptionTiers).where(eq(subscriptionTiers.id, tierId)).limit(1);
  return result[0] || null;
}

export async function createSubscriptionTier(tier: InsertSubscriptionTier) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.insert(subscriptionTiers).values(tier);
  return result;
}

// User Subscription Helpers
export async function getUserSubscription(userId: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(userSubscriptions).where(eq(userSubscriptions.userId, userId)).limit(1);
  return result[0] || null;
}

export async function createUserSubscription(subscription: InsertUserSubscription) {
  const db = await getDb();
  if (!db) return null;
  return db.insert(userSubscriptions).values(subscription);
}

export async function updateUserSubscriptionStatus(subscriptionId: number, status: "active" | "cancelled" | "expired") {
  const db = await getDb();
  if (!db) return null;
  return db.update(userSubscriptions)
    .set({ status, updatedAt: new Date() })
    .where(eq(userSubscriptions.id, subscriptionId));
}

// Premium Content Helpers
export async function getPremiumContent(slug: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(premiumContent).where(eq(premiumContent.slug, slug)).limit(1);
  return result[0] || null;
}

export async function getPublishedPremiumContent() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(premiumContent).where(eq(premiumContent.published, 1));
}

export async function createPremiumContent(content: InsertPremiumContent) {
  const db = await getDb();
  if (!db) return null;
  return db.insert(premiumContent).values(content);
}

export async function updatePremiumContent(id: number, content: Partial<InsertPremiumContent>) {
  const db = await getDb();
  if (!db) return null;
  return db.update(premiumContent)
    .set({ ...content, updatedAt: new Date() })
    .where(eq(premiumContent.id, id));
}

// Subscriber Helpers
export async function getSubscriberByEmail(email: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(subscribers).where(eq(subscribers.email, email)).limit(1);
  return result[0] || null;
}

export async function createSubscriber(subscriber: InsertSubscriber) {
  const db = await getDb();
  if (!db) return null;
  return db.insert(subscribers).values(subscriber);
}

export async function updateSubscriber(id: number, subscriber: Partial<InsertSubscriber>) {
  const db = await getDb();
  if (!db) return null;
  return db.update(subscribers)
    .set({ ...subscriber, updatedAt: new Date() })
    .where(eq(subscribers.id, id));
}

export async function getSubscriberCount() {
  const db = await getDb();
  if (!db) return 0;
  const result = await db.select().from(subscribers);
  return result.length;
}
