import { z } from "zod";
import { publicProcedure, router } from "./_core/trpc";
import { invokeLLM } from "./_core/llm";

export const quizRouter = router({
  getRecommendations: publicProcedure
    .input(z.object({
      role: z.string(), // "developer", "marketer", "founder", "student"
      hoursToSave: z.string(), // "5", "10", "20"
      painPoint: z.string(), // "writing", "automation", "research", "video"
      budget: z.string(), // "free", "cheap", "premium"
    }))
    .mutation(async ({ input }) => {
      const tools = [
        {
          name: "ChatGPT Plus",
          description: "Advanced AI assistant for writing, coding, and analysis",
          affiliate: "https://openai.com/chatgpt",
          commission: "Up to $20/signup",
          icon: "🤖",
          bestFor: ["writing", "coding", "research"],
        },
        {
          name: "Perplexity AI",
          description: "Real-time search + AI reasoning for research",
          affiliate: "https://www.perplexity.ai",
          commission: "Up to $15/signup",
          icon: "🔍",
          bestFor: ["research", "analysis"],
        },
        {
          name: "Claude 3.5",
          description: "Best-in-class reasoning and document analysis",
          affiliate: "https://claude.ai",
          commission: "Up to $25/signup",
          icon: "✨",
          bestFor: ["writing", "analysis", "coding"],
        },
        {
          name: "Synthesia",
          description: "AI video generation from text in minutes",
          affiliate: "https://www.synthesia.io",
          commission: "30% recurring",
          icon: "🎬",
          bestFor: ["video", "marketing"],
        },
        {
          name: "Zapier",
          description: "Automate workflows between 7000+ apps",
          affiliate: "https://zapier.com",
          commission: "30% recurring",
          icon: "⚡",
          bestFor: ["automation"],
        },
        {
          name: "Notion AI",
          description: "AI-powered workspace for docs and databases",
          affiliate: "https://www.notion.so",
          commission: "20% recurring",
          icon: "📝",
          bestFor: ["organization", "writing"],
        },
      ];

      // Use AI to analyze and recommend
      const prompt = `Based on the following user profile, recommend the top 3 AI tools from this list that would be most helpful:

User Profile:
- Role: ${input.role}
- Hours they want to save per week: ${input.hoursToSave}
- Main pain point: ${input.painPoint}
- Budget: ${input.budget}

Available Tools:
${tools.map(t => `- ${t.name}: ${t.description} (Best for: ${t.bestFor.join(", ")})`).join("\n")}

Provide your response as JSON with this exact format:
{
  "recommendations": [
    {
      "name": "tool name",
      "reason": "why this tool is perfect for them",
      "savesHours": "estimated hours saved per week",
      "roi": "return on investment explanation"
    }
  ],
  "summary": "brief personalized summary"
}`;

      const response = await invokeLLM({
        messages: [
          {
            role: "system",
            content: "You are an AI expert who recommends the best productivity tools based on user needs. Always respond with valid JSON.",
          },
          {
            role: "user",
            content: prompt,
          },
        ],
        response_format: {
          type: "json_schema",
          json_schema: {
            name: "tool_recommendations",
            strict: true,
            schema: {
              type: "object",
              properties: {
                recommendations: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      name: { type: "string" },
                      reason: { type: "string" },
                      savesHours: { type: "string" },
                      roi: { type: "string" },
                    },
                    required: ["name", "reason", "savesHours", "roi"],
                  },
                },
                summary: { type: "string" },
              },
              required: ["recommendations", "summary"],
            },
          },
        },
      });

      // Parse AI response and match with affiliate links
      let recommendations = [];
      try {
        const content = response.choices[0].message.content;
        const contentStr = typeof content === 'string' ? content : JSON.stringify(content);
        const parsed = JSON.parse(contentStr);
        
        recommendations = (parsed.recommendations || []).map((rec: any) => {
          const tool = tools.find(t => t.name.toLowerCase() === rec.name.toLowerCase());
          return {
            name: rec.name,
            reason: rec.reason,
            savesHours: rec.savesHours,
            roi: rec.roi,
            affiliate: tool?.affiliate || "#",
            commission: tool?.commission || "N/A",
            icon: tool?.icon || "🔧",
          };
        });
      } catch (e) {
        // Fallback: return top 3 tools based on pain point
        const filtered = tools.filter(t => 
          t.bestFor.includes(input.painPoint.toLowerCase())
        ).slice(0, 3);
        
        recommendations = filtered.map(t => ({
          name: t.name,
          reason: `Perfect for ${input.painPoint}`,
          savesHours: `${input.hoursToSave}+ hours/week`,
          roi: "High ROI for your workflow",
          affiliate: t.affiliate,
          commission: t.commission,
          icon: t.icon,
        }));
      }

      return {
        recommendations,
        summary: `Based on your profile, these tools will help you save ${input.hoursToSave}+ hours per week.`,
      };
    }),
});
