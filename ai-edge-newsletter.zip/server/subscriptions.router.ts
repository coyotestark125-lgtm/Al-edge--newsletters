import { z } from "zod";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import {
  getSubscriptionTiers,
  getUserSubscription,
  getPremiumContent,
  getPublishedPremiumContent,
  getSubscriberByEmail,
  createSubscriber,
} from "./db-helpers";

export const subscriptionsRouter = router({
  // Get all subscription tiers (free and premium)
  getTiers: publicProcedure.query(async () => {
    return getSubscriptionTiers();
  }),

  // Get user's current subscription
  getCurrentSubscription: protectedProcedure.query(async ({ ctx }) => {
    return getUserSubscription(ctx.user.id);
  }),

  // Get premium content by slug
  getContent: publicProcedure
    .input(z.object({ slug: z.string() }))
    .query(async ({ input }) => {
      return getPremiumContent(input.slug);
    }),

  // Get all published premium content
  getAllContent: publicProcedure.query(async () => {
    return getPublishedPremiumContent();
  }),

  // Subscribe to newsletter (free)
  subscribeNewsletter: publicProcedure
    .input(z.object({
      email: z.string().email(),
      name: z.string().optional(),
    }))
    .mutation(async ({ input }) => {
      const existing = await getSubscriberByEmail(input.email);
      if (existing) {
        return { success: false, message: "Already subscribed" };
      }
      
      await createSubscriber({
        email: input.email,
        name: input.name,
        subscriptionStatus: "subscribed",
      });

      return { success: true, message: "Subscribed successfully" };
    }),
});
