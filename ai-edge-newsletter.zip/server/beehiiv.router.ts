import { z } from "zod";
import { publicProcedure, router } from "./_core/trpc";
import { subscribeToBeehiiv } from "./beehiiv";

export const beehiivRouter = router({
  subscribe: publicProcedure
    .input(
      z.object({
        email: z.string().email(),
        name: z.string().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const result = await subscribeToBeehiiv(input.email, input.name);
      return result;
    }),
});
