import { ENV } from "./_core/env";

/**
 * Subscribe a user to Beehiiv publication
 */
export async function subscribeToBeehiiv(email: string, name?: string) {
  const apiKey = process.env.BEEHIIV_API_KEY;

  if (!apiKey) {
    console.warn("[Beehiiv] API key not configured");
    return { success: false, error: "Beehiiv not configured" };
  }

  try {
    const response = await fetch("https://api.beehiiv.com/v1/publications/subscribe", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        email,
        name: name || undefined,
        reactivate_existing: true,
      }),
    });

    if (!response.ok) {
      const error = await response.json();
      console.error("[Beehiiv] Subscription error:", error);
      return { success: false, error: error.message || "Failed to subscribe" };
    }

    const data = await response.json();
    console.log("[Beehiiv] Subscription successful:", email);
    return { success: true, data };
  } catch (error) {
    console.error("[Beehiiv] Request failed:", error);
    return { success: false, error: "Network error" };
  }
}
