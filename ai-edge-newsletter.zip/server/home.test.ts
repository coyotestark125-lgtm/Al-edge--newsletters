import { describe, it, expect } from "vitest";

// Test the data structures and content that power the Home page
describe("Home Page Content", () => {
  const tools = [
    { name: "ChatGPT Plus", category: "Writing & Code", commission: "Up to $20/signup" },
    { name: "Perplexity AI", category: "Research", commission: "Up to $15/signup" },
    { name: "Claude Pro", category: "Analysis", commission: "Up to $25/signup" },
    { name: "Synthesia", category: "Video", commission: "30% recurring" },
    { name: "Zapier", category: "Automation", commission: "30% recurring" },
    { name: "Notion AI", category: "Productivity", commission: "20% recurring" },
  ];

  const testimonials = [
    { name: "Sarah Chen", role: "Marketing Director", avatar: "SC" },
    { name: "Marcus Johnson", role: "Freelance Writer", avatar: "MJ" },
    { name: "Priya Patel", role: "Startup Founder", avatar: "PP" },
  ];

  const faqs = [
    "What is AI Edge Newsletter?",
    "Is it really free?",
    "How often do you send emails?",
    "What kind of AI tools do you cover?",
    "How do I unsubscribe?",
  ];

  it("should have exactly 6 featured tools", () => {
    expect(tools).toHaveLength(6);
  });

  it("should have unique tool names", () => {
    const names = tools.map((t) => t.name);
    expect(new Set(names).size).toBe(names.length);
  });

  it("should have categories for all tools", () => {
    tools.forEach((tool) => {
      expect(tool.category).toBeTruthy();
      expect(tool.commission).toBeTruthy();
    });
  });

  it("should have exactly 3 testimonials", () => {
    expect(testimonials).toHaveLength(3);
  });

  it("should have 2-letter avatars for testimonials", () => {
    testimonials.forEach((t) => {
      expect(t.avatar).toHaveLength(2);
    });
  });

  it("should have exactly 5 FAQ items", () => {
    expect(faqs).toHaveLength(5);
  });

  it("should include unsubscribe FAQ", () => {
    const hasUnsubscribe = faqs.some((q) => q.toLowerCase().includes("unsubscribe"));
    expect(hasUnsubscribe).toBe(true);
  });

  it("should include pricing/free FAQ", () => {
    const hasFree = faqs.some((q) => q.toLowerCase().includes("free"));
    expect(hasFree).toBe(true);
  });
});
