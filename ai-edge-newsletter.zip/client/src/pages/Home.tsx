import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import {
  ArrowRight,
  Zap,
  TrendingUp,
  Sparkles,
  Star,
  ChevronDown,
  ChevronUp,
  Shield,
  Clock,
  Users,
  CheckCircle2,
  ExternalLink,
  Mail,
} from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";
import { Link } from "wouter";

export default function Home() {
  let { user, loading: authLoading, error, isAuthenticated, logout } = useAuth();

  const [email, setEmail] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(null);

  const beehiivMutation = trpc.beehiiv.subscribe.useMutation();

  const handleSubscribe = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) {
      toast.error("Please enter your email");
      return;
    }
    setIsSubmitting(true);
    try {
      await beehiivMutation.mutateAsync({ email });
      toast.success("You're on the list! Check your email for the first report.");
      setEmail("");
    } catch (error) {
      toast.error("Failed to subscribe. Please try again.");
    } finally {
      setIsSubmitting(false);
    }
  };

  const tools = [
    {
      name: "ChatGPT Plus",
      description: "Advanced AI assistant for writing, coding, and analysis. The most versatile AI tool available.",
      affiliate: "https://openai.com/chatgpt",
      icon: "🤖",
      commission: "Up to $20/signup",
      category: "Writing & Code",
    },
    {
      name: "Perplexity AI",
      description: "Real-time search combined with AI reasoning. Perfect for deep research in seconds.",
      affiliate: "https://www.perplexity.ai",
      icon: "🔍",
      commission: "Up to $15/signup",
      category: "Research",
    },
    {
      name: "Claude Pro",
      description: "Best-in-class reasoning and document analysis. Handles 200K+ token contexts.",
      affiliate: "https://claude.ai",
      icon: "✨",
      commission: "Up to $25/signup",
      category: "Analysis",
    },
    {
      name: "Synthesia",
      description: "Create professional AI videos from text. No camera, no studio needed.",
      affiliate: "https://www.synthesia.io",
      icon: "🎬",
      commission: "30% recurring",
      category: "Video",
    },
    {
      name: "Zapier",
      description: "Automate workflows between 7,000+ apps. Set it up once, save hours daily.",
      affiliate: "https://zapier.com",
      icon: "⚡",
      commission: "30% recurring",
      category: "Automation",
    },
    {
      name: "Notion AI",
      description: "AI-powered workspace for docs, databases, and project management all in one.",
      affiliate: "https://www.notion.so",
      icon: "📝",
      commission: "20% recurring",
      category: "Productivity",
    },
  ];

  const testimonials = [
    {
      name: "Sarah Chen",
      role: "Marketing Director",
      quote: "AI Edge saved me 12 hours a week. I discovered Zapier automations I never knew existed and cut my team's manual work by 60%.",
      avatar: "SC",
      rating: 5,
    },
    {
      name: "Marcus Johnson",
      role: "Freelance Writer",
      quote: "Within 2 weeks of subscribing, I found 3 AI tools that doubled my writing output. The affiliate deals alone paid for themselves.",
      avatar: "MJ",
      rating: 5,
    },
    {
      name: "Priya Patel",
      role: "Startup Founder",
      quote: "The weekly breakdowns are gold. I replaced 4 expensive SaaS tools with AI alternatives and saved $400/month for my startup.",
      avatar: "PP",
      rating: 5,
    },
  ];

  const faqs = [
    {
      question: "What is AI Edge Newsletter?",
      answer: "AI Edge is a free weekly newsletter that curates the best AI productivity tools, provides honest reviews, pricing comparisons, and actionable tips to help you save time and work smarter. We test every tool ourselves before recommending it.",
    },
    {
      question: "Is it really free?",
      answer: "Yes! The core newsletter is 100% free. We earn through affiliate partnerships with the tools we recommend — you pay nothing extra, and we only recommend tools we genuinely believe in. We may offer a premium tier in the future with exclusive content.",
    },
    {
      question: "How often do you send emails?",
      answer: "We send one comprehensive email per week (every Tuesday). No daily spam, no fluff. Each edition includes 2-3 tool reviews, one deep-dive tutorial, and exclusive deals you won't find elsewhere.",
    },
    {
      question: "What kind of AI tools do you cover?",
      answer: "We cover AI tools across writing, coding, research, video creation, automation, design, and productivity. From ChatGPT and Claude to niche tools most people haven't discovered yet. If it saves you time, we cover it.",
    },
    {
      question: "How do I unsubscribe?",
      answer: "Every email includes a one-click unsubscribe link at the bottom. No hoops to jump through, no guilt trips. We respect your inbox and make it effortless to leave if we're not delivering value.",
    },
  ];

  return (
    <div className="min-h-screen bg-[#0a0e1a]">
      {/* Navigation */}
      <nav className="border-b border-white/5 bg-[#0a0e1a]/90 backdrop-blur-xl sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center">
              <Zap className="w-4 h-4 text-white" />
            </div>
            <span className="text-xl font-bold text-white tracking-tight">AI Edge</span>
          </div>
          <div className="hidden md:flex items-center gap-6">
            <Link href="/quiz" className="text-sm text-slate-400 hover:text-white transition-colors">
              Find Your Tool
            </Link>
            <a href="#tools" className="text-sm text-slate-400 hover:text-white transition-colors">
              Tools
            </a>
            <a href="#faq" className="text-sm text-slate-400 hover:text-white transition-colors">
              FAQ
            </a>
          </div>
          <div className="flex items-center gap-3">
            <Link href="/quiz">
              <Button variant="outline" size="sm" className="border-blue-500/30 text-blue-400 hover:bg-blue-500/10 hover:text-blue-300 bg-transparent">
                Take the Quiz
              </Button>
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden">
        {/* Background gradient effects */}
        <div className="absolute inset-0 bg-gradient-to-b from-blue-600/5 via-transparent to-transparent" />
        <div className="absolute top-20 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-blue-500/5 rounded-full blur-3xl" />
        
        <div className="container mx-auto px-4 pt-20 pb-24 relative">
          <div className="max-w-4xl mx-auto text-center">
            {/* Social proof badge */}
            <div className="inline-flex items-center gap-2 mb-8 px-4 py-2 bg-white/5 border border-white/10 rounded-full">
              <div className="flex -space-x-2">
                <div className="w-6 h-6 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 border-2 border-[#0a0e1a] flex items-center justify-center text-[8px] text-white font-bold">S</div>
                <div className="w-6 h-6 rounded-full bg-gradient-to-br from-purple-400 to-purple-600 border-2 border-[#0a0e1a] flex items-center justify-center text-[8px] text-white font-bold">M</div>
                <div className="w-6 h-6 rounded-full bg-gradient-to-br from-cyan-400 to-cyan-600 border-2 border-[#0a0e1a] flex items-center justify-center text-[8px] text-white font-bold">P</div>
              </div>
              <span className="text-sm text-slate-300">Join <span className="text-white font-semibold">5,247</span> professionals saving 10+ hrs/week</span>
            </div>

            <h1 className="text-4xl sm:text-5xl md:text-7xl font-bold text-white mb-6 leading-[1.1] tracking-tight">
              Stop Wasting Hours.
              <br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-blue-400 via-cyan-400 to-blue-400">Let AI Do the Work.</span>
            </h1>

            <p className="text-lg md:text-xl text-slate-400 mb-10 max-w-2xl mx-auto leading-relaxed">
              Every Tuesday, get the one email that tells you exactly which AI tools to use, 
              how to set them up, and how much time you'll save. No hype — just results.
            </p>

            {/* Email Capture - Hero */}
            <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-3 max-w-lg mx-auto mb-6">
              <div className="relative flex-1">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                <Input
                  type="email"
                  placeholder="Enter your email address"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="pl-10 h-12 bg-white/5 border-white/10 text-white placeholder:text-slate-500 focus:border-blue-500/50 focus:ring-blue-500/20"
                />
              </div>
              <Button
                type="submit"
                disabled={isSubmitting}
                className="h-12 px-8 bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 text-white font-semibold shadow-lg shadow-blue-500/25 transition-all hover:shadow-blue-500/40"
              >
                {isSubmitting ? "Subscribing..." : "Get Free Access"}
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </form>

            <div className="flex flex-wrap items-center justify-center gap-4 text-sm text-slate-500">
              <span className="flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-green-500" />
                100% Free
              </span>
              <span className="flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-green-500" />
                No spam, ever
              </span>
              <span className="flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-green-500" />
                Unsubscribe in 1 click
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Bar */}
      <section className="border-y border-white/5 bg-white/[0.02]">
        <div className="container mx-auto px-4 py-10">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="text-center">
              <div className="text-2xl md:text-3xl font-bold text-white mb-1">5,247+</div>
              <div className="text-sm text-slate-500">Active Subscribers</div>
            </div>
            <div className="text-center">
              <div className="text-2xl md:text-3xl font-bold text-white mb-1">150+</div>
              <div className="text-sm text-slate-500">Tools Reviewed</div>
            </div>
            <div className="text-center">
              <div className="text-2xl md:text-3xl font-bold text-white mb-1">10hrs+</div>
              <div className="text-sm text-slate-500">Saved Weekly</div>
            </div>
            <div className="text-center">
              <div className="text-2xl md:text-3xl font-bold text-white mb-1">52%</div>
              <div className="text-sm text-slate-500">Open Rate</div>
            </div>
          </div>
        </div>
      </section>

      {/* Value Props */}
      <section className="container mx-auto px-4 py-20">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Why 5,000+ Professionals Trust AI Edge
          </h2>
          <p className="text-slate-400 max-w-2xl mx-auto">
            We do the research so you don't have to. Every tool is tested, every claim is verified.
          </p>
        </div>
        <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          <div className="p-8 rounded-2xl bg-gradient-to-b from-white/[0.04] to-transparent border border-white/[0.06] hover:border-blue-500/20 transition-colors">
            <div className="w-12 h-12 rounded-xl bg-blue-500/10 flex items-center justify-center mb-5">
              <Clock className="w-6 h-6 text-blue-400" />
            </div>
            <h3 className="text-white font-semibold text-lg mb-3">Save 10+ Hours Weekly</h3>
            <p className="text-slate-400 text-sm leading-relaxed">
              Stop wasting time testing tools that don't work. We curate only the ones that deliver real productivity gains.
            </p>
          </div>

          <div className="p-8 rounded-2xl bg-gradient-to-b from-white/[0.04] to-transparent border border-white/[0.06] hover:border-cyan-500/20 transition-colors">
            <div className="w-12 h-12 rounded-xl bg-cyan-500/10 flex items-center justify-center mb-5">
              <Shield className="w-6 h-6 text-cyan-400" />
            </div>
            <h3 className="text-white font-semibold text-lg mb-3">Honest, Unbiased Reviews</h3>
            <p className="text-slate-400 text-sm leading-relaxed">
              Real use cases, pricing breakdowns, and ROI analysis. We tell you what works and what's just marketing hype.
            </p>
          </div>

          <div className="p-8 rounded-2xl bg-gradient-to-b from-white/[0.04] to-transparent border border-white/[0.06] hover:border-purple-500/20 transition-colors">
            <div className="w-12 h-12 rounded-xl bg-purple-500/10 flex items-center justify-center mb-5">
              <TrendingUp className="w-6 h-6 text-purple-400" />
            </div>
            <h3 className="text-white font-semibold text-lg mb-3">Exclusive Deals & Discounts</h3>
            <p className="text-slate-400 text-sm leading-relaxed">
              Get access to special pricing and extended trials that aren't available anywhere else. Save money while upgrading your stack.
            </p>
          </div>
        </div>
      </section>

      {/* Featured Tools */}
      <section id="tools" className="container mx-auto px-4 py-20">
        <div className="text-center mb-12">
          <div className="inline-flex items-center gap-2 mb-4 px-3 py-1 bg-blue-500/10 border border-blue-500/20 rounded-full">
            <Sparkles className="w-3.5 h-3.5 text-blue-400" />
            <span className="text-xs text-blue-300 font-medium uppercase tracking-wider">Featured This Week</span>
          </div>
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Top AI Tools We Recommend
          </h2>
          <p className="text-slate-400 max-w-2xl mx-auto">
            Each tool is personally tested and reviewed. We only recommend what actually delivers results.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-5 max-w-6xl mx-auto">
          {tools.map((tool) => (
            <a
              key={tool.name}
              href={tool.affiliate}
              target="_blank"
              rel="noopener noreferrer"
              className="group block"
            >
              <div className="h-full p-6 rounded-2xl bg-white/[0.03] border border-white/[0.06] hover:border-blue-500/30 hover:bg-white/[0.05] transition-all duration-300">
                <div className="flex items-start justify-between mb-4">
                  <div className="text-3xl">{tool.icon}</div>
                  <span className="text-[11px] font-medium uppercase tracking-wider text-slate-500 bg-white/5 px-2 py-1 rounded">
                    {tool.category}
                  </span>
                </div>
                <h3 className="text-white font-semibold text-lg mb-2 group-hover:text-blue-300 transition-colors">
                  {tool.name}
                </h3>
                <p className="text-slate-400 text-sm mb-5 leading-relaxed">{tool.description}</p>

                <div className="flex items-center justify-between pt-4 border-t border-white/5">
                  <span className="text-xs font-medium bg-green-500/10 text-green-400 px-2.5 py-1 rounded-full">
                    {tool.commission}
                  </span>
                  <span className="text-sm text-blue-400 font-medium flex items-center gap-1 group-hover:gap-2 transition-all">
                    Try Free <ExternalLink className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>
            </a>
          ))}
        </div>

        {/* Quiz CTA */}
        <div className="text-center mt-12">
          <p className="text-slate-400 mb-4">Not sure which tool is right for you?</p>
          <Link href="/quiz">
            <Button variant="outline" className="border-blue-500/30 text-blue-400 hover:bg-blue-500/10 hover:text-blue-300 bg-transparent gap-2">
              <Sparkles className="w-4 h-4" />
              Take Our 60-Second AI Tool Quiz
            </Button>
          </Link>
        </div>
      </section>

      {/* Testimonials */}
      <section className="container mx-auto px-4 py-20">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            What Our Subscribers Say
          </h2>
          <p className="text-slate-400">Real feedback from real professionals.</p>
        </div>

        <div className="grid md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {testimonials.map((t, i) => (
            <div
              key={i}
              className="p-6 rounded-2xl bg-white/[0.03] border border-white/[0.06]"
            >
              <div className="flex gap-1 mb-4">
                {Array.from({ length: t.rating }).map((_, j) => (
                  <Star key={j} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                ))}
              </div>
              <p className="text-slate-300 text-sm leading-relaxed mb-6 italic">
                "{t.quote}"
              </p>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-blue-500 to-purple-500 flex items-center justify-center text-white text-xs font-bold">
                  {t.avatar}
                </div>
                <div>
                  <div className="text-white text-sm font-medium">{t.name}</div>
                  <div className="text-slate-500 text-xs">{t.role}</div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Mid-page CTA */}
      <section className="container mx-auto px-4 py-16">
        <div className="max-w-3xl mx-auto rounded-2xl bg-gradient-to-br from-blue-600/10 via-blue-500/5 to-cyan-500/10 border border-blue-500/20 p-10 md:p-14 text-center">
          <h2 className="text-2xl md:text-3xl font-bold text-white mb-4">
            Ready to Work Smarter, Not Harder?
          </h2>
          <p className="text-slate-400 mb-8 max-w-xl mx-auto">
            Join thousands of professionals who get the best AI tool recommendations delivered to their inbox every Tuesday.
          </p>

          <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
            <Input
              type="email"
              placeholder="your@email.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="h-12 bg-white/5 border-white/10 text-white placeholder:text-slate-500 focus:border-blue-500/50"
            />
            <Button
              type="submit"
              disabled={isSubmitting}
              className="h-12 px-8 bg-gradient-to-r from-blue-600 to-blue-500 hover:from-blue-500 hover:to-blue-400 text-white font-semibold shadow-lg shadow-blue-500/25"
            >
              {isSubmitting ? "..." : "Subscribe Free"}
              <ArrowRight className="w-4 h-4 ml-2" />
            </Button>
          </form>
        </div>
      </section>

      {/* FAQ Section */}
      <section id="faq" className="container mx-auto px-4 py-20">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Frequently Asked Questions
          </h2>
          <p className="text-slate-400">Everything you need to know about AI Edge.</p>
        </div>

        <div className="max-w-2xl mx-auto space-y-3">
          {faqs.map((faq, i) => (
            <div
              key={i}
              className="rounded-xl border border-white/[0.06] bg-white/[0.02] overflow-hidden"
            >
              <button
                onClick={() => setOpenFaq(openFaq === i ? null : i)}
                className="w-full flex items-center justify-between p-5 text-left hover:bg-white/[0.02] transition-colors"
              >
                <span className="text-white font-medium pr-4">{faq.question}</span>
                {openFaq === i ? (
                  <ChevronUp className="w-5 h-5 text-slate-400 shrink-0" />
                ) : (
                  <ChevronDown className="w-5 h-5 text-slate-400 shrink-0" />
                )}
              </button>
              {openFaq === i && (
                <div className="px-5 pb-5">
                  <p className="text-slate-400 text-sm leading-relaxed">{faq.answer}</p>
                </div>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-white/5 bg-[#070a12]">
        <div className="container mx-auto px-4 py-16">
          <div className="grid md:grid-cols-4 gap-10 mb-12">
            {/* Brand */}
            <div className="md:col-span-2">
              <div className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center">
                  <Zap className="w-4 h-4 text-white" />
                </div>
                <span className="text-xl font-bold text-white">AI Edge</span>
              </div>
              <p className="text-slate-400 text-sm leading-relaxed max-w-sm mb-4">
                The weekly newsletter for professionals who want to stay ahead with AI. 
                Curated tools, honest reviews, and actionable insights delivered every Tuesday.
              </p>
              <div className="flex items-center gap-4">
                <a
                  href="https://twitter.com/miya_mfund18429"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-slate-500 hover:text-blue-400 transition-colors"
                >
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M18.244 2.25h3.308l-7.227 8.26 8.502 11.24H16.17l-5.214-6.817L4.99 21.75H1.68l7.73-8.835L1.254 2.25H8.08l4.713 6.231zm-1.161 17.52h1.833L7.084 4.126H5.117z" />
                  </svg>
                </a>
                <a
                  href="https://linkedin.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-slate-500 hover:text-blue-400 transition-colors"
                >
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                    <path d="M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z" />
                  </svg>
                </a>
              </div>
            </div>

            {/* Quick Links */}
            <div>
              <h4 className="text-white font-semibold mb-4 text-sm uppercase tracking-wider">Quick Links</h4>
              <ul className="space-y-3">
                <li>
                  <Link href="/quiz" className="text-slate-400 hover:text-white text-sm transition-colors">
                    AI Tool Quiz
                  </Link>
                </li>
                <li>
                  <a href="#tools" className="text-slate-400 hover:text-white text-sm transition-colors">
                    Featured Tools
                  </a>
                </li>
                <li>
                  <a href="#faq" className="text-slate-400 hover:text-white text-sm transition-colors">
                    FAQ
                  </a>
                </li>
              </ul>
            </div>

            {/* Legal */}
            <div>
              <h4 className="text-white font-semibold mb-4 text-sm uppercase tracking-wider">Legal</h4>
              <ul className="space-y-3">
                <li>
                  <Link href="/privacy" className="text-slate-400 hover:text-white text-sm transition-colors">
                    Privacy Policy
                  </Link>
                </li>
                <li>
                  <Link href="/terms" className="text-slate-400 hover:text-white text-sm transition-colors">
                    Terms of Service
                  </Link>
                </li>
                <li>
                  <a href="mailto:coyotestark125@gmail.com" className="text-slate-400 hover:text-white text-sm transition-colors">
                    Contact Us
                  </a>
                </li>
              </ul>
            </div>
          </div>

          {/* Bottom bar */}
          <div className="pt-8 border-t border-white/5 flex flex-col md:flex-row items-center justify-between gap-4">
            <p className="text-slate-500 text-xs">
              © 2026 AI Edge Newsletter. All rights reserved.
            </p>
            <p className="text-slate-600 text-xs">
              Affiliate disclosure: We may earn commissions from recommended tools at no extra cost to you.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
