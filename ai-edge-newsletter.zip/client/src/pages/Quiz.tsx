import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowRight, Sparkles, CheckCircle } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

type QuizStep = "role" | "hours" | "painpoint" | "budget" | "results";

export default function Quiz() {
  const [step, setStep] = useState<QuizStep>("role");
  const [answers, setAnswers] = useState({
    role: "",
    hoursToSave: "",
    painPoint: "",
    budget: "",
  });
  const [isLoading, setIsLoading] = useState(false);
  const [results, setResults] = useState<any>(null);

  const getRecommendations = trpc.quiz.getRecommendations.useMutation();

  const handleNext = async () => {
    if (step === "role" && !answers.role) {
      toast.error("Please select your role");
      return;
    }
    if (step === "hours" && !answers.hoursToSave) {
      toast.error("Please select hours to save");
      return;
    }
    if (step === "painpoint" && !answers.painPoint) {
      toast.error("Please select your pain point");
      return;
    }
    if (step === "budget" && !answers.budget) {
      toast.error("Please select your budget");
      return;
    }

    if (step === "budget") {
      // Get recommendations
      setIsLoading(true);
      try {
        const res = await getRecommendations.mutateAsync({
          role: answers.role,
          hoursToSave: answers.hoursToSave,
          painPoint: answers.painPoint,
          budget: answers.budget,
        });
        setResults(res);
        setStep("results");
      } catch (error) {
        toast.error("Failed to get recommendations");
      } finally {
        setIsLoading(false);
      }
    } else {
      const steps: QuizStep[] = ["role", "hours", "painpoint", "budget"];
      const currentIndex = steps.indexOf(step);
      setStep(steps[currentIndex + 1]);
    }
  };

  const handleBack = () => {
    const steps: QuizStep[] = ["role", "hours", "painpoint", "budget"];
    const currentIndex = steps.indexOf(step);
    if (currentIndex > 0) {
      setStep(steps[currentIndex - 1]);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <div className="border-b border-slate-700/50 bg-slate-900/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center gap-3">
            <Sparkles className="w-8 h-8 text-blue-400" />
            <h1 className="text-3xl font-bold text-white">Find Your Perfect AI Tools</h1>
          </div>
          <p className="text-slate-400 mt-2">Answer a few questions and get personalized recommendations</p>
        </div>
      </div>

      {/* Quiz Container */}
      <div className="container mx-auto px-4 py-12">
        <div className="max-w-2xl mx-auto">
          {/* Progress Bar */}
          <div className="mb-8">
            <div className="flex gap-2 mb-4">
              {["role", "hours", "painpoint", "budget"].map((s, i) => (
                <div
                  key={s}
                  className={`h-2 flex-1 rounded-full transition-all ${
                    ["role", "hours", "painpoint", "budget"].indexOf(step) >= i
                      ? "bg-blue-500"
                      : "bg-slate-700"
                  }`}
                />
              ))}
            </div>
            <p className="text-sm text-slate-400">
              Step {["role", "hours", "painpoint", "budget"].indexOf(step) + 1} of 4
            </p>
          </div>

          {/* Step: Role */}
          {step === "role" && (
            <Card className="bg-slate-800/50 border-slate-700 p-8">
              <h2 className="text-2xl font-bold text-white mb-6">What's your role?</h2>
              <div className="grid gap-4">
                {[
                  { value: "developer", label: "👨‍💻 Developer", desc: "I write code" },
                  { value: "marketer", label: "📊 Marketer", desc: "I create campaigns" },
                  { value: "founder", label: "🚀 Founder", desc: "I run a business" },
                  { value: "student", label: "📚 Student", desc: "I'm learning" },
                ].map((option) => (
                  <button
                    key={option.value}
                    onClick={() => setAnswers({ ...answers, role: option.value })}
                    className={`p-4 rounded-lg border-2 transition-all text-left ${
                      answers.role === option.value
                        ? "border-blue-500 bg-blue-500/10"
                        : "border-slate-700 hover:border-slate-600"
                    }`}
                  >
                    <div className="font-semibold text-white">{option.label}</div>
                    <div className="text-sm text-slate-400">{option.desc}</div>
                  </button>
                ))}
              </div>
            </Card>
          )}

          {/* Step: Hours */}
          {step === "hours" && (
            <Card className="bg-slate-800/50 border-slate-700 p-8">
              <h2 className="text-2xl font-bold text-white mb-6">How many hours per week do you want to save?</h2>
              <div className="grid gap-4">
                {[
                  { value: "5", label: "5 hours", desc: "Just getting started" },
                  { value: "10", label: "10 hours", desc: "Moderate time savings" },
                  { value: "20", label: "20+ hours", desc: "Maximum efficiency" },
                ].map((option) => (
                  <button
                    key={option.value}
                    onClick={() => setAnswers({ ...answers, hoursToSave: option.value })}
                    className={`p-4 rounded-lg border-2 transition-all text-left ${
                      answers.hoursToSave === option.value
                        ? "border-blue-500 bg-blue-500/10"
                        : "border-slate-700 hover:border-slate-600"
                    }`}
                  >
                    <div className="font-semibold text-white">{option.label}</div>
                    <div className="text-sm text-slate-400">{option.desc}</div>
                  </button>
                ))}
              </div>
            </Card>
          )}

          {/* Step: Pain Point */}
          {step === "painpoint" && (
            <Card className="bg-slate-800/50 border-slate-700 p-8">
              <h2 className="text-2xl font-bold text-white mb-6">What's your main pain point?</h2>
              <div className="grid gap-4">
                {[
                  { value: "writing", label: "✍️ Writing", desc: "Content creation" },
                  { value: "automation", label: "⚙️ Automation", desc: "Repetitive tasks" },
                  { value: "research", label: "🔍 Research", desc: "Finding information" },
                  { value: "video", label: "🎬 Video", desc: "Creating videos" },
                ].map((option) => (
                  <button
                    key={option.value}
                    onClick={() => setAnswers({ ...answers, painPoint: option.value })}
                    className={`p-4 rounded-lg border-2 transition-all text-left ${
                      answers.painPoint === option.value
                        ? "border-blue-500 bg-blue-500/10"
                        : "border-slate-700 hover:border-slate-600"
                    }`}
                  >
                    <div className="font-semibold text-white">{option.label}</div>
                    <div className="text-sm text-slate-400">{option.desc}</div>
                  </button>
                ))}
              </div>
            </Card>
          )}

          {/* Step: Budget */}
          {step === "budget" && (
            <Card className="bg-slate-800/50 border-slate-700 p-8">
              <h2 className="text-2xl font-bold text-white mb-6">What's your budget?</h2>
              <div className="grid gap-4">
                {[
                  { value: "free", label: "💰 Free", desc: "No cost" },
                  { value: "cheap", label: "💵 Cheap", desc: "$0-50/month" },
                  { value: "premium", label: "💎 Premium", desc: "$50+/month" },
                ].map((option) => (
                  <button
                    key={option.value}
                    onClick={() => setAnswers({ ...answers, budget: option.value })}
                    className={`p-4 rounded-lg border-2 transition-all text-left ${
                      answers.budget === option.value
                        ? "border-blue-500 bg-blue-500/10"
                        : "border-slate-700 hover:border-slate-600"
                    }`}
                  >
                    <div className="font-semibold text-white">{option.label}</div>
                    <div className="text-sm text-slate-400">{option.desc}</div>
                  </button>
                ))}
              </div>
            </Card>
          )}

          {/* Results */}
          {step === "results" && results && (
            <div className="space-y-6">
              <Card className="bg-gradient-to-r from-blue-600/20 to-cyan-600/20 border border-blue-500/30 p-8">
                <div className="flex items-start gap-4">
                  <CheckCircle className="w-8 h-8 text-green-400 mt-1 flex-shrink-0" />
                  <div>
                    <h2 className="text-2xl font-bold text-white mb-2">Your Personalized Recommendations</h2>
                    <p className="text-slate-300">{results.summary}</p>
                  </div>
                </div>
              </Card>

              {results.recommendations.map((rec: any, i: number) => (
                <Card key={i} className="bg-slate-800/50 border-slate-700 p-6 hover:border-blue-500/50 transition-all">
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <div className="text-3xl mb-2">{rec.icon}</div>
                      <h3 className="text-xl font-bold text-white">{rec.name}</h3>
                    </div>
                    <span className="text-xs bg-green-500/20 text-green-300 px-3 py-1 rounded-full">
                      {rec.commission}
                    </span>
                  </div>

                  <p className="text-slate-300 mb-4">{rec.reason}</p>

                  <div className="grid grid-cols-2 gap-4 mb-6">
                    <div className="bg-slate-900/50 p-3 rounded">
                      <p className="text-xs text-slate-400 mb-1">Time Saved</p>
                      <p className="text-white font-semibold">{rec.savesHours}</p>
                    </div>
                    <div className="bg-slate-900/50 p-3 rounded">
                      <p className="text-xs text-slate-400 mb-1">ROI</p>
                      <p className="text-white font-semibold">{rec.roi}</p>
                    </div>
                  </div>

                  <a
                    href={rec.affiliate}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-all"
                  >
                    Start Free Trial <ArrowRight className="w-4 h-4" />
                  </a>
                </Card>
              ))}

              <Button
                onClick={() => {
                  setStep("role");
                  setAnswers({ role: "", hoursToSave: "", painPoint: "", budget: "" });
                  setResults(null);
                }}
                className="w-full bg-slate-700 hover:bg-slate-600"
              >
                Take Quiz Again
              </Button>
            </div>
          )}

          {/* Navigation */}
          {step !== "results" && (
            <div className="flex gap-4 mt-8">
              <Button
                onClick={handleBack}
                variant="outline"
                disabled={step === "role"}
                className="flex-1"
              >
                Back
              </Button>
              <Button
                onClick={handleNext}
                disabled={isLoading}
                className="flex-1 bg-blue-600 hover:bg-blue-700"
              >
                {isLoading ? "Loading..." : step === "budget" ? "Get Recommendations" : "Next"}
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
