import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Lock, BookOpen, Users, Settings } from "lucide-react";
import { useLocation } from "wouter";

export default function Dashboard() {
  const { user, isAuthenticated } = useAuth();
  const [, setLocation] = useLocation();

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 to-slate-800">
        <Card className="bg-slate-800 border-slate-700 p-8 max-w-md">
          <Lock className="w-12 h-12 text-blue-400 mb-4" />
          <h1 className="text-2xl font-bold text-white mb-4">Premium Access Required</h1>
          <p className="text-slate-300 mb-6">
            Subscribe to unlock premium content, guides, and exclusive tools.
          </p>
          <Button 
            onClick={() => setLocation("/")}
            className="w-full bg-blue-600 hover:bg-blue-700"
          >
            View Pricing
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900">
      {/* Header */}
      <div className="border-b border-slate-700/50 bg-slate-900/80 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-6">
          <h1 className="text-3xl font-bold text-white">Premium Dashboard</h1>
          <p className="text-slate-400 mt-2">Welcome, {user?.name || user?.email}</p>
        </div>
      </div>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-12">
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {/* Premium Guides */}
          <Card className="bg-slate-800/50 border-slate-700 p-6 hover:border-blue-500/50 transition-all">
            <BookOpen className="w-8 h-8 text-blue-400 mb-4" />
            <h3 className="text-white font-semibold mb-2">Premium Guides</h3>
            <p className="text-slate-400 text-sm mb-4">
              Access exclusive guides on mastering AI tools and maximizing productivity.
            </p>
            <Button variant="outline" className="w-full">
              View Guides
            </Button>
          </Card>

          {/* Community */}
          <Card className="bg-slate-800/50 border-slate-700 p-6 hover:border-cyan-500/50 transition-all">
            <Users className="w-8 h-8 text-cyan-400 mb-4" />
            <h3 className="text-white font-semibold mb-2">Community</h3>
            <p className="text-slate-400 text-sm mb-4">
              Join our private community of AI enthusiasts and professionals.
            </p>
            <Button variant="outline" className="w-full">
              Join Discord
            </Button>
          </Card>

          {/* Account Settings */}
          <Card className="bg-slate-800/50 border-slate-700 p-6 hover:border-purple-500/50 transition-all">
            <Settings className="w-8 h-8 text-purple-400 mb-4" />
            <h3 className="text-white font-semibold mb-2">Account</h3>
            <p className="text-slate-400 text-sm mb-4">
              Manage your subscription, billing, and preferences.
            </p>
            <Button variant="outline" className="w-full">
              Settings
            </Button>
          </Card>
        </div>

        {/* Featured Content */}
        <div className="mb-12">
          <h2 className="text-2xl font-bold text-white mb-6">Latest Premium Content</h2>
          <div className="grid md:grid-cols-2 gap-6">
            {[1, 2, 3, 4].map((i) => (
              <Card key={i} className="bg-slate-800/50 border-slate-700 p-6">
                <div className="h-40 bg-gradient-to-br from-blue-500/20 to-cyan-500/20 rounded-lg mb-4 flex items-center justify-center">
                  <span className="text-slate-400">Content Placeholder</span>
                </div>
                <h3 className="text-white font-semibold mb-2">Premium Content {i}</h3>
                <p className="text-slate-400 text-sm mb-4">
                  Exclusive guide on maximizing AI tools for your workflow.
                </p>
                <Button variant="outline" className="w-full">
                  Read More
                </Button>
              </Card>
            ))}
          </div>
        </div>

        {/* Subscription Info */}
        <Card className="bg-gradient-to-r from-blue-600/20 to-cyan-600/20 border border-blue-500/30 p-8">
          <h2 className="text-2xl font-bold text-white mb-4">Your Subscription</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div>
              <p className="text-slate-400 mb-2">Current Plan</p>
              <p className="text-2xl font-bold text-white">Premium Monthly</p>
            </div>
            <div>
              <p className="text-slate-400 mb-2">Renewal Date</p>
              <p className="text-2xl font-bold text-white">May 28, 2026</p>
            </div>
            <div>
              <p className="text-slate-400 mb-2">Status</p>
              <p className="text-2xl font-bold text-green-400">Active</p>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
