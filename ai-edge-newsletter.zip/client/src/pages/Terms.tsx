import { Zap } from "lucide-react";
import { Link } from "wouter";

export default function Terms() {
  return (
    <div className="min-h-screen bg-[#0a0e1a]">
      <nav className="border-b border-white/5 bg-[#0a0e1a]/90 backdrop-blur-xl sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center gap-2">
          <Link href="/" className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center">
              <Zap className="w-4 h-4 text-white" />
            </div>
            <span className="text-xl font-bold text-white">AI Edge</span>
          </Link>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-16 max-w-3xl">
        <h1 className="text-3xl font-bold text-white mb-8">Terms of Service</h1>
        <div className="prose prose-invert prose-sm max-w-none space-y-6 text-slate-300">
          <p><strong className="text-white">Last updated:</strong> May 1, 2026</p>

          <h2 className="text-xl font-semibold text-white mt-8">1. Acceptance of Terms</h2>
          <p>By subscribing to AI Edge Newsletter or using our website, you agree to these terms. If you do not agree, please do not use our services.</p>

          <h2 className="text-xl font-semibold text-white mt-8">2. Newsletter Service</h2>
          <p>AI Edge provides a free weekly newsletter with AI tool recommendations and reviews. We reserve the right to modify the frequency, format, or content of the newsletter at any time.</p>

          <h2 className="text-xl font-semibold text-white mt-8">3. Affiliate Disclosure</h2>
          <p>Our content contains affiliate links. We may earn commissions when you purchase through these links. This does not affect the price you pay. We only recommend tools we have personally tested and believe provide genuine value.</p>

          <h2 className="text-xl font-semibold text-white mt-8">4. Content Disclaimer</h2>
          <p>The information provided in our newsletter and website is for informational purposes only. We make no guarantees about the accuracy, completeness, or reliability of any tool reviews or recommendations. Results may vary.</p>

          <h2 className="text-xl font-semibold text-white mt-8">5. Intellectual Property</h2>
          <p>All content on this website and in our newsletters is owned by AI Edge. You may not reproduce, distribute, or republish our content without written permission.</p>

          <h2 className="text-xl font-semibold text-white mt-8">6. Limitation of Liability</h2>
          <p>AI Edge is not liable for any damages arising from your use of recommended tools or services. You use all third-party tools at your own risk.</p>

          <h2 className="text-xl font-semibold text-white mt-8">7. Changes to Terms</h2>
          <p>We may update these terms at any time. Continued use of our services after changes constitutes acceptance of the new terms.</p>

          <h2 className="text-xl font-semibold text-white mt-8">8. Contact</h2>
          <p>Questions about these terms? Contact us at: <a href="mailto:coyotestark125@gmail.com" className="text-blue-400 hover:text-blue-300">coyotestark125@gmail.com</a></p>
        </div>
      </div>
    </div>
  );
}
