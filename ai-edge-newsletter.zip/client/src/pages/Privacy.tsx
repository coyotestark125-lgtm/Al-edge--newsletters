import { Zap } from "lucide-react";
import { Link } from "wouter";

export default function Privacy() {
  return (
    <div className="min-h-screen bg-[#0a0e1a]">
      <nav className="border-b border-white/5 bg-[#0a0e1a]/90 backdrop-blur-xl sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex items-center gap-2">
          <Link href="/" className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-cyan-400 flex items-center justify-center">
              <Zap className="w-4 h-4 text-white" />
            </div>
            <span className="text-xl font-bold text-white">AI Edge</span>
          </Link>
        </div>
      </nav>

      <div className="container mx-auto px-4 py-16 max-w-3xl">
        <h1 className="text-3xl font-bold text-white mb-8">Privacy Policy</h1>
        <div className="prose prose-invert prose-sm max-w-none space-y-6 text-slate-300">
          <p><strong className="text-white">Last updated:</strong> May 1, 2026</p>

          <h2 className="text-xl font-semibold text-white mt-8">1. Information We Collect</h2>
          <p>We collect your email address when you subscribe to our newsletter. We do not collect any other personal information unless you voluntarily provide it.</p>

          <h2 className="text-xl font-semibold text-white mt-8">2. How We Use Your Information</h2>
          <p>Your email address is used solely to send you our weekly AI Edge newsletter. We may also send occasional announcements about new features or premium offerings.</p>

          <h2 className="text-xl font-semibold text-white mt-8">3. Third-Party Services</h2>
          <p>We use Beehiiv as our email service provider. Your email address is stored securely on their platform. We do not sell, trade, or share your email with any other third parties.</p>

          <h2 className="text-xl font-semibold text-white mt-8">4. Affiliate Links</h2>
          <p>Our newsletter and website contain affiliate links. When you click these links and make a purchase, we may earn a commission at no additional cost to you. These affiliate partners may use cookies to track referrals.</p>

          <h2 className="text-xl font-semibold text-white mt-8">5. Cookies</h2>
          <p>We use essential cookies to maintain your session and preferences. No tracking cookies are used for advertising purposes.</p>

          <h2 className="text-xl font-semibold text-white mt-8">6. Your Rights</h2>
          <p>You can unsubscribe from our newsletter at any time by clicking the unsubscribe link in any email. You may also contact us to request deletion of your data.</p>

          <h2 className="text-xl font-semibold text-white mt-8">7. Contact</h2>
          <p>For privacy-related questions, contact us at: <a href="mailto:coyotestark125@gmail.com" className="text-blue-400 hover:text-blue-300">coyotestark125@gmail.com</a></p>
        </div>
      </div>
    </div>
  );
}
